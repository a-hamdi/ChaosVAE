from setuptools import setup

setup(
    name='VAE_utils_package',
    version='1.0',
    scripts=['Utils.py'],
)